// scenes/01-the-wire.ts — Scene A geometry: the Internet between the machines.
// The HOME side is geometrically IDENTICAL to Chapter 02's web scene (case,
// window, hardware row — 02 §6 spatial stability, 02 §17 orientation). The
// world simply extends further east, where Ch-02 drew its single rail: the
// Server stands at the far end of a web of Routers.

import type { InfrastructureDescription, Vec2 } from '../../../chapter-loader/types'
import type { PartSpec, Rect } from '../types'

// ---- world + home (Ch-02 coordinates, verbatim) ---------------------------
export const BBOX_WIRE = { minX: 40, maxX: 1940, minY: 40, maxY: 940 }
export const CASE = { x: 60, y: 80, w: 840, h: 790 }
export const WINDOW = { x: 90, y: 130, w: 760, h: 470 }
export const URLBAR = { x: 190, y: 152, w: 600, h: 36 } as Rect
export const VIEWPORT = { x: 106, y: 212, w: 728, h: 372 } as Rect
export const URL_TEXT = 'https://best-cats.example'

// ---- the road: Routers + the Server ----------------------------------------
// Main route (east → west, the bytes' direction): Server door → R4 → R3 →
// R2 → R1 → home edge. The alternate branch: R3 → R2b → R1 (Packet 2's way
// around the busy cable). M1/M6 guard: every node is drawn as a computer.
export const SERVER = { x: 1840, y: 520 } as Vec2
export const DOOR = { x: 1762, y: 520 } as Vec2 // server box west face
export const CLOG = { x: 1672, y: 430 } as Vec2 // where the whole-file attempt stalls (above the cable, clear of the box)
export const HOVER = { x: 1697, y: 430 } as Vec2 // the file's resting spot at the door
export const R4 = { x: 1560, y: 520 } as Vec2
export const R3 = { x: 1360, y: 610 } as Vec2
export const R2 = { x: 1170, y: 430 } as Vec2 // the congested one (drops Packet 4)
export const R2B = { x: 1170, y: 710 } as Vec2 // the alternate branch
export const R1 = { x: 990, y: 520 } as Vec2
export const EDGE = { x: 850, y: 520 } as Vec2 // home's exit point (Ch-02's rail origin)
export const CORNER = { x: 850, y: 805 } as Vec2
export const NIC_POS = { x: 260, y: 805 } as Vec2
export const RAM_POS = { x: 430, y: 805 } as Vec2
export const CPU_POS = { x: 590, y: 805 } as Vec2
export const GPU_POS = { x: 740, y: 805 } as Vec2

// ---- protagonist path (12 points; every beat resumes at the prior end) -----
export const PATH_A: Vec2[] = [
  HOVER, //       0  the file hovers above the door (b0 emerge, b1 reveal)
  CLOG, //        1  the whole-file attempt stalls here (b2)
  HOVER, //       2  dup — the block retreats, gets sliced (b3)
  R4, //          3  hop 1
  R3, //          4  hop 2 (the branch point)
  R2, //          5  hop 3 (the congested one)
  R1, //          6  hop 4 (last before home)
  EDGE, //        7  the home edge
  CORNER, //      8  down into the hardware row
  NIC_POS, //     9  the NIC (b4 arrives + dwells here; b5 rests here)
  RAM_POS, //    10  RAM — the hand-off rest (b11)
  RAM_POS, //    11  dup — recap rest (b12 loop)
]

// ---- the machines -----------------------------------------------------------
export const browser: PartSpec = {
  id: 'browser',
  kind: 'browser-lite',
  pos: { x: 470, y: 410 },
  color: '#22d3ee',
  name: 'Browser',
  gloss: {
    en: 'The main character of the last journey. Right now it simply waits: its page is still on the road.',
    vi: 'Nhân vật chính của hành trình trước. Lúc này nó chỉ đơn giản là chờ: trang của nó vẫn còn trên đường.',
  },
}

export const nic: PartSpec = {
  id: 'nic',
  kind: 'nic',
  pos: NIC_POS,
  color: '#a5b4fc',
  name: 'NIC',
  gloss: {
    en: 'Your computer\u2019s door to the network; you met it before. Every byte that enters lands here first.',
    vi: 'Cánh cửa ra mạng của máy tính; bạn đã gặp nó rồi. Mọi byte đi vào đều hạ cánh ở đây trước tiên.',
  },
}

export const ram: PartSpec = {
  id: 'ram',
  kind: 'ram-filled',
  pos: RAM_POS,
  color: '#facc15',
  name: 'RAM',
  gloss: {
    en: 'Fast working memory from Chapter 1. The finished file waits here, ready for the Browser.',
    vi: 'Bộ nhớ làm việc nhanh từ Chapter 1. Tệp hoàn chỉnh chờ ở đây, sẵn sàng cho Browser.',
  },
}

export const cpu: PartSpec = {
  id: 'cpu',
  kind: 'cpu-chip',
  pos: CPU_POS,
  color: '#fb923c',
  name: 'CPU',
  gloss: {
    en: 'The CPU runs everything you are watching here, the Browser, TCP, the whole machine, one instruction at a time, just like Chapter 1.',
    vi: 'CPU chạy mọi thứ bạn đang thấy ở đây, Browser, TCP, cả cỗ máy, từng lệnh một, đúng như Chapter 1.',
  },
}

export const gpu: PartSpec = {
  id: 'gpu',
  kind: 'gpu',
  pos: GPU_POS,
  color: '#4ade80',
  name: 'GPU',
  gloss: {
    en: 'The GPU is resting: the page is not drawn yet. Its work belongs to the last journey.',
    vi: 'GPU đang nghỉ: trang vẫn chưa được vẽ. Việc của nó thuộc về hành trình trước.',
  },
}

export const server: PartSpec = {
  id: 'server',
  kind: 'service-box',
  pos: SERVER,
  color: '#22d3ee',
  name: 'Server',
  gloss: {
    en: 'The computer that answered your Browser. Right now it holds your page, and when a piece goes missing, it sends that piece again.',
    vi: 'Cỗ máy đã trả lời Browser của bạn. Lúc này nó giữ trang của bạn, và khi một mảnh thất lạc, nó gửi lại đúng mảnh đó.',
  },
}

const routerGloss = {
  en: 'A computer whose whole job is passing things along. It reads where a packet is headed, then hands it to the neighbor closest to that place. It keeps nothing: every packet moves on in a blink.',
  vi: 'Một máy tính mà cả công việc là chuyển tiếp. Nó đọc xem packet đang đi đâu, rồi trao cho người hàng xóm gần đích nhất. Nó không giữ lại gì: mọi packet đi tiếp trong chớp mắt.',
}

export const router4: PartSpec = { id: 'router4', kind: 'router', pos: R4, color: '#a78bfa', name: 'Router', gloss: routerGloss }
export const router3: PartSpec = { id: 'router3', kind: 'router', pos: R3, color: '#a78bfa', name: 'Router', gloss: routerGloss }
export const router2: PartSpec = { id: 'router2', kind: 'router', pos: R2, color: '#a78bfa', name: 'Router', gloss: routerGloss }
export const router2b: PartSpec = { id: 'router2b', kind: 'router', pos: R2B, color: '#a78bfa', name: 'Router', gloss: routerGloss }
export const router1: PartSpec = { id: 'router1', kind: 'router', pos: R1, color: '#a78bfa', name: 'Router', gloss: routerGloss }

// ---- infrastructure (case + hardware rail only; the mesh cables are painted
// by wire-traffic so the b1 reveal can animate them in) -----------------------
export const WIRE_INFRASTRUCTURE: InfrastructureDescription[] = [
  { id: 'case', kind: 'case', rect: CASE },
  {
    id: 'hw-rail',
    kind: 'bus-rail',
    points: [NIC_POS, GPU_POS],
  },
]

// ---- hit-zone: the Server box (the learner sends the response) --------------
export const SERVER_RECT = { x: SERVER.x - 78, y: SERVER.y - 59, w: 156, h: 118 } as Rect
