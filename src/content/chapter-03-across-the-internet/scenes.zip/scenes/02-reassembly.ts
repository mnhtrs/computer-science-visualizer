// scenes/02-reassembly.ts — Scene B geometry: INSIDE the receiving machine.
// The NIC port in the ceiling (the same NIC, seen from inside), TCP's
// Reassembly Buffer bench in the middle, the RAM door in the floor. Every
// piece that entered through the NIC waits here until the file is whole.

import type { InfrastructureDescription, Vec2 } from '../../../chapter-loader/types'
import type { PartSpec, Rect } from '../types'

export const BBOX_BENCH = { minX: 80, maxX: 1320, minY: 10, maxY: 950 }

// ---- the ceiling door (same NIC, inside view) ------------------------------
export const PORT = { x: 700, y: 80 } as Vec2

// ---- the bench --------------------------------------------------------------
export const BENCH: Rect = { x: 140, y: 260, w: 1120, h: 420 }

// Five numbered slots, 84×84, y center 430.
export const SLOT_W = 84
export const SLOT_Y = 430
export const SLOT_X = [340, 520, 700, 880, 1060]
export const SLOT_POS: Vec2[] = SLOT_X.map((x) => ({ x, y: SLOT_Y }))

// The merge zone (payload strips fuse here) + the floor exit.
export const MERGE = { x: 700, y: 600 } as Vec2
export const RAM_DOOR = { x: 700, y: 860 } as Vec2

// ---- protagonist path (9 points): the keeper's attention walks slot to slot,
// dwelling (via beats.ts holdAt) where each piece lands. Pieces descend from
// the port on their own window, timed to land as the keeper arrives — no dead
// return-legs, no desync. ------------------------------------------------------
export const PATH_B: Vec2[] = [
  PORT, //        0  in through the ceiling door (escorts Piece 1)
  SLOT_POS[0], // 1  slot 1
  SLOT_POS[2], // 2  slot 3 (Piece 3 lands as the keeper arrives)
  SLOT_POS[4], // 3  slot 5 (Piece 5)
  SLOT_POS[1], // 4  slot 2 (Piece 2 — counter jumps)
  SLOT_POS[3], // 5  slot 4 (Piece 4 returns — the gap closes)
  MERGE, //       6  the merge zone
  RAM_DOOR, //    7  the floor exit — the file settles into RAM
  RAM_DOOR, //    8  dup — fade-out seam
]

// ---- entities ----------------------------------------------------------------
export const nicport: PartSpec = {
  id: 'nicport',
  kind: 'port',
  pos: PORT,
  color: '#a5b4fc',
  name: 'NIC Port',
  labelSize: 14,
  gloss: {
    en: 'The door seen from inside, the same NIC. Pieces come in through it, and the ACKs leave through it.',
    vi: 'Cánh cửa nhìn từ bên trong, chính là NIC đó. Các mảnh đi vào qua nó, và các ACK đi ra qua nó.',
  },
}

export const bench: PartSpec = {
  id: 'bench',
  kind: 'reassembly-bench',
  pos: { x: BENCH.x + BENCH.w / 2, y: BENCH.y + BENCH.h / 2 },
  color: '#e2e8f0',
  name: 'Reassembly Buffer',
  labelSize: 18,
  gloss: {
    en: 'TCP\u2019s bench: a numbered slot for every piece, where the file waits to be stitched whole.',
    vi: 'Chiếc bàn của TCP: mỗi mảnh một ô đánh số, nơi tệp chờ được khâu lại nguyên vẹn.',
  },
}

export const ramDoor: PartSpec = {
  id: 'ramDoor',
  kind: 'ram',
  pos: RAM_DOOR,
  color: '#facc15',
  name: 'RAM',
  gloss: {
    en: 'Fast working memory from Chapter 1. The finished file waits here, ready for the Browser.',
    vi: 'Bộ nhớ làm việc nhanh từ Chapter 1. Tệp hoàn chỉnh chờ ở đây, sẵn sàng cho Browser.',
  },
}

// ---- infrastructure (the cable stub back out to the network) ------------------
export const BENCH_INFRASTRUCTURE: InfrastructureDescription[] = [
  {
    id: 'port-cable',
    kind: 'cable',
    points: [
      { x: 700, y: 40 },
      { x: 700, y: 20 },
    ],
  },
]
