// content/chapter-03-across-the-internet/renderers.ts
// Chapter 03 entity renderers — built from the shared primitives with the
// canonical physics (Ch-01/Ch-02 style: glow-on-active, dim-when-idle 0.55,
// orbit rest, easeInOutCubic). Every renderer is a pure function of
// (PresentationState, entity): beat-driven content derives from beatIndex /
// beatElapsed, so scrubbing, pausing and stepping stay deterministic
// (Constitution 02 §15). No renderer imports React or the Viewer.

import type { EntityRenderer } from '../../rendering/types'
import type { Vec2 } from '../../chapter-loader/types'
import { FONT, hexA, rrPath } from '../../rendering/primitives/canvas-utils'
import { glow } from '../../rendering/primitives/glow'
import { drawName } from '../../rendering/primitives/text'
import { TAU, clamp, easeInOutCubic, lerp } from '../../shared/math'
import { polylinePoint } from '../../shared/geometry'

import { beats } from './narration/beats'
import {
  CABLES, ROUTER_REVEAL, MAIN_PATH, BRANCH_PATH, DROP_PARAM,
  CHIP_FORMATION, CHIP_WINDOWS, TRAY_POS, TRAY_GHOST, TRAY_LANDING,
  FILE_BLOCK, SERVER_IP,
  STAGE_AT_BEAT, STAGE_CAPTIONS, ACK_AT_BEAT, ACK_START, ACK_FLIP,
  SLOTS_AT_BEAT, INCOMING,
} from './scenes/03-story'
import {
  WINDOW, URLBAR, VIEWPORT, URL_TEXT,
  DOOR, CLOG, EDGE, NIC_POS, HOVER,
} from './scenes/01-the-wire'
import { BENCH, SLOT_POS, SLOT_W, PORT, MERGE, RAM_DOOR } from './scenes/02-reassembly'

const MONO = "'JetBrains Mono', ui-monospace, SFMono-Regular, Menlo, monospace"
const DUR: Record<number, number> = Object.fromEntries(beats.map((b, i) => [i, b.duration]))

const lerpPt = (a: Vec2, b: Vec2, t: number): Vec2 => ({ x: lerp(a.x, b.x, t), y: lerp(a.y, b.y, t) })
const beatFrac = (s: { beatIndex: number; beatElapsed: number }, bi = s.beatIndex) => ({
  lin: clamp(s.beatElapsed / (DUR[bi] ?? 3000), 0, 1),
  frac: easeInOutCubic(clamp(s.beatElapsed / (DUR[bi] ?? 3000), 0, 1)),
})

// ===========================================================================
// Shared payload painters (file block + packet chip — the SAME shapes at the
// server door, on the road, in the tray, on the bench: structure vs state)
// ===========================================================================
function drawFileBlock(ctx: CanvasRenderingContext2D, pos: Vec2, alpha: number, scale = 1) {
  if (alpha <= 0.01) return
  const w = FILE_BLOCK.w * scale
  const h = FILE_BLOCK.h * scale
  ctx.save()
  ctx.globalAlpha = alpha
  rrPath(ctx, pos.x - w / 2, pos.y - h / 2, w, h, 8)
  ctx.fillStyle = hexA('#facc15', 0.2)
  ctx.fill()
  ctx.strokeStyle = hexA('#facc15', 0.95)
  ctx.lineWidth = 2
  ctx.stroke()
  ctx.fillStyle = hexA('#facc15', 0.95)
  ctx.font = `700 ${11 * scale}px ${MONO}`
  ctx.textAlign = 'left'
  ctx.textBaseline = 'middle'
  ctx.fillText(FILE_BLOCK.tag, pos.x - w / 2 + 10, pos.y - 6 * scale)
  ctx.fillStyle = 'rgba(225,235,255,0.92)'
  ctx.font = `600 ${11 * scale}px ${FONT}`
  ctx.fillText(FILE_BLOCK.label, pos.x - w / 2 + 10, pos.y + 8 * scale)
  ctx.restore()
}

function drawChip(ctx: CanvasRenderingContext2D, pos: Vec2, k: number, alpha: number, scale = 1) {
  if (alpha <= 0.01) return
  const w = 54 * scale
  const h = 34 * scale
  ctx.save()
  ctx.globalAlpha = alpha
  rrPath(ctx, pos.x - w / 2, pos.y - h / 2, w, h, 8)
  ctx.fillStyle = hexA('#facc15', 0.16)
  ctx.fill()
  ctx.strokeStyle = hexA('#facc15', 0.9)
  ctx.lineWidth = 1.8
  ctx.stroke()
  // the header band (where from / where to / which number live)
  rrPath(ctx, pos.x - w / 2, pos.y - h / 2, w, 9 * scale, 8)
  ctx.fillStyle = hexA('#facc15', 0.42)
  ctx.fill()
  ctx.fillStyle = '#fff'
  ctx.font = `800 ${15 * scale}px ${MONO}`
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(`#${k}`, pos.x, pos.y + 5 * scale)
  ctx.restore()
}

// ===========================================================================
// SERVICE BOX — the Server (canonical Ch-02 look: disks glyph + IP pill).
// The IP pill shows from beat 0: the same number DNS handed over in Ch-02.
// ===========================================================================
export const drawServiceBox: EntityRenderer = (ctx, s, e, active) => {
  ctx.save()
  ctx.globalAlpha = active ? 1 : 0.55
  if (active) glow(ctx, e.pos, e.color, 110, 0.42 + 0.1 * Math.sin(s.t * 0.006))
  const w = 156
  const h = 118
  const x = e.pos.x - w / 2
  const y = e.pos.y - h / 2
  rrPath(ctx, x, y, w, h, 14)
  ctx.fillStyle = hexA(e.color, active ? 0.18 : 0.1)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, active ? 0.95 : 0.45)
  ctx.lineWidth = 2
  ctx.stroke()
  const cy = e.pos.y - 17
  for (let i = 0; i < 3; i++) {
    rrPath(ctx, e.pos.x - 22, cy - 18 + i * 14, 44, 10, 3)
    ctx.fillStyle = hexA(e.color, 0.35)
    ctx.fill()
    ctx.strokeStyle = hexA('#ffffff', 0.75)
    ctx.lineWidth = 1.2
    ctx.stroke()
  }
  if (active) {
    for (let i = 0; i < 3; i++) {
      const a = s.t * 0.01 + (i * TAU) / 3
      ctx.fillStyle = hexA('#ffffff', 0.5 + 0.4 * Math.sin(a))
      ctx.beginPath()
      ctx.arc(e.pos.x - 10 + i * 10, e.pos.y + 14, 3, 0, TAU)
      ctx.fill()
    }
  }
  // the IP pill — continuity callback, visible from the first beat
  ctx.font = `700 14px ${MONO}`
  const iw = ctx.measureText(SERVER_IP).width + 24
  const pillY = e.pos.y + h / 2 - 8 - 24
  rrPath(ctx, e.pos.x - iw / 2, pillY, iw, 24, 12)
  ctx.fillStyle = 'rgba(8,12,30,0.95)'
  ctx.fill()
  ctx.strokeStyle = hexA('#facc15', 0.8)
  ctx.lineWidth = 1.5
  ctx.stroke()
  ctx.fillStyle = '#facc15'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(SERVER_IP, e.pos.x, pillY + 12)
  ctx.restore()
  drawName(ctx, e.pos, e.name, e.color, active, 74)
}

// ===========================================================================
// ROUTER — a computer whose job is forwarding. Hidden at b0 (the learner
// still imagines a straight wire); pops in staggered during b1; proximity
// glow whenever a packet passes. Chevrons point WEST — the bytes' direction.
// ===========================================================================
export const drawRouter: EntityRenderer = (ctx, s, e, active) => {
  const bi = s.beatIndex
  // reveal timing comes through extra.revealAt (set in assemble.ts)
  const revealAt = Number((e.extra ?? {}).revealAt ?? 0)
  let appear = 1
  if (bi < 1) appear = 0
  else if (bi === 1) {
    const lin1 = clamp(s.beatElapsed / (DUR[1] ?? 4200), 0, 1)
    appear = easeInOutCubic(clamp((lin1 - revealAt) / 0.14, 0, 1))
  }
  if (appear <= 0.01) return

  const dSpark = Math.hypot(s.sparkPos.x - e.pos.x, s.sparkPos.y - e.pos.y)
  const pulse = Math.pow(clamp(1 - dSpark / 130, 0, 1), 2)
  const congested = (e.extra ?? {}).congested === true && bi >= 4

  ctx.save()
  ctx.globalAlpha = (active ? 1 : 0.55) * appear
  ctx.translate(e.pos.x, e.pos.y)
  const sc = 0.6 + 0.4 * appear
  ctx.scale(sc, sc)
  if (active) glow(ctx, { x: 0, y: 0 }, e.color, 95, 0.4 + 0.1 * Math.sin(s.t * 0.006))
  if (pulse > 0.02) glow(ctx, { x: 0, y: 0 }, e.color, 105, 0.3 * pulse)
  const w = 96
  const h = 62
  rrPath(ctx, -w / 2, -h / 2, w, h, 12)
  ctx.fillStyle = hexA(e.color, active || pulse > 0.3 ? 0.2 : 0.1)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, active ? 0.95 : 0.45 + 0.4 * pulse)
  ctx.lineWidth = active ? 2.5 : 2
  ctx.stroke()
  // forwarding chevrons, pointing west (the way home)
  ctx.strokeStyle = hexA(active || pulse > 0.3 ? '#ffffff' : e.color, active ? 0.9 : 0.55 + 0.35 * pulse)
  ctx.lineWidth = 3
  ctx.lineCap = 'round'
  ctx.lineJoin = 'round'
  for (let i = 0; i < 3; i++) {
    const cx = 14 - i * 14
    ctx.beginPath()
    ctx.moveTo(cx + 7, -10)
    ctx.lineTo(cx - 5, 0)
    ctx.lineTo(cx + 7, 10)
    ctx.stroke()
  }
  if (congested) {
    // two queued dim dots east of the box — the busy cable made visible
    for (let i = 0; i < 2; i++) {
      ctx.fillStyle = hexA('#fb923c', 0.5 + 0.2 * Math.sin(s.t * 0.008 + i))
      ctx.beginPath()
      ctx.arc(w / 2 + 14 + i * 13, i === 0 ? -6 : 8, 3.5, 0, TAU)
      ctx.fill()
    }
  }
  ctx.restore()
  // the name fades in WITH the box (drawName sets its own colour alpha, so
  // multiply it by the reveal factor via globalAlpha)
  ctx.save()
  ctx.globalAlpha = appear
  drawName(ctx, e.pos, e.name, e.color, active, 40, 14)
  ctx.restore()
}

// ===========================================================================
// NIC — canonical Ch-01/Ch-02 network card. Brightens as the spark dwells.
// ===========================================================================
export const drawNIC: EntityRenderer = (ctx, s, e, active) => {
  const dSpark = Math.hypot(s.sparkPos.x - e.pos.x, s.sparkPos.y - e.pos.y)
  const pulse = Math.pow(clamp(1 - dSpark / 110, 0, 1), 2)
  ctx.save()
  ctx.globalAlpha = active ? 1 : Math.max(0.55, 0.55 + 0.45 * pulse)
  if (active) glow(ctx, e.pos, e.color, 90, 0.4 + 0.1 * Math.sin(s.t * 0.005))
  if (pulse > 0.01) glow(ctx, e.pos, e.color, 100, 0.32 * pulse)
  const w = 74
  const h = 30
  rrPath(ctx, e.pos.x - w / 2, e.pos.y - h / 2, w, h, 6)
  ctx.fillStyle = hexA(e.color, active ? 0.22 : 0.12)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, active ? 0.95 : 0.5)
  ctx.lineWidth = 2
  ctx.stroke()
  for (let i = 0; i < 3; i++) {
    ctx.fillStyle = hexA(active ? '#ffffff' : e.color, active ? 0.75 : 0.55)
    ctx.fillRect(e.pos.x - 24 + i * 20, e.pos.y - 5, 12, 10)
  }
  ctx.restore()
  drawName(ctx, e.pos, e.name, e.color, active)
}

// ===========================================================================
// RAM (filled) — shared RAM look + the golden "HTML" fill from the hand-off
// beat (b11): the whole file settling in. Ch-02's exact RAM, honestly filled.
// ===========================================================================
export const drawRamFilled: EntityRenderer = (ctx, s, e, active) => {
  const t = s.t
  const from = Number((e.extra ?? {}).fillFromBeat ?? 11)
  const fillDur = Number((e.extra ?? {}).fillDur ?? 3200)
  let fill = 0
  if (s.beatIndex === from) fill = easeInOutCubic(clamp(s.beatElapsed / fillDur, 0, 1))
  else if (s.beatIndex > from) fill = 1
  ctx.save()
  ctx.globalAlpha = active ? 1 : 0.5
  if (active || fill > 0) glow(ctx, e.pos, e.color, 90, (active ? 0.4 : 0.24) + 0.1 * Math.sin(t * 0.005) + 0.2 * fill)
  const x = e.pos.x - 30
  const y = e.pos.y - 14
  rrPath(ctx, x, y, 60, 28, 6)
  ctx.fillStyle = hexA(e.color, active ? 0.22 : 0.12)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, active ? 0.95 : 0.5)
  ctx.lineWidth = 2
  ctx.stroke()
  for (let i = 0; i < 4; i++) {
    rrPath(ctx, x + 8 + i * 12, y + 7, 7, 14, 2)
    ctx.fillStyle = hexA(e.color, active ? 0.9 : 0.5)
    ctx.fill()
  }
  if (fill > 0.01) {
    // the file's presence: a golden fill + the honest label
    ctx.save()
    rrPath(ctx, x, y, 60, 28, 6)
    ctx.clip()
    ctx.fillStyle = hexA('#facc15', 0.3 * fill)
    ctx.fillRect(x, y, 60 * fill, 28)
    ctx.restore()
    ctx.fillStyle = hexA('#facc15', fill)
    ctx.font = `800 13px ${MONO}`
    ctx.textAlign = 'center'
    ctx.textBaseline = 'bottom'
    ctx.fillText('HTML', e.pos.x, y - 5)
  }
  ctx.restore()
  drawName(ctx, e.pos, e.name, e.color, active)
}

// ===========================================================================
// BROWSER (lite) — Ch-02's window, honestly frozen in its LOADING state for
// the whole chapter (the page is not rendered yet — that is Ch-02's Act 3).
// ===========================================================================
export const drawBrowserLite: EntityRenderer = (ctx, s, e, active) => {
  const W = WINDOW
  const V = VIEWPORT
  const U = URLBAR
  ctx.save()
  if (active) glow(ctx, e.pos, e.color, 160, 0.18 + 0.05 * Math.sin(s.t * 0.004))
  rrPath(ctx, W.x, W.y, W.w, W.h, 22)
  ctx.fillStyle = 'rgba(16,22,48,0.92)'
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, active ? 0.75 : 0.35)
  ctx.lineWidth = 2.5
  ctx.stroke()
  // chrome dots
  const cx = W.x + 26
  const cy = W.y + 30
  ;['#fb7185', '#facc15', '#4ade80'].forEach((c, i) => {
    ctx.fillStyle = hexA(c, 0.85)
    ctx.beginPath()
    ctx.arc(cx + i * 20, cy, 6, 0, TAU)
    ctx.fill()
  })
  // url pill with padlock + the carried-over URL
  rrPath(ctx, U.x, U.y, U.w, U.h, U.h / 2)
  ctx.fillStyle = 'rgba(8,12,30,0.9)'
  ctx.fill()
  ctx.strokeStyle = 'rgba(150,170,255,0.18)'
  ctx.lineWidth = 1.5
  ctx.stroke()
  const pcy = U.y + U.h / 2
  ctx.strokeStyle = hexA('#facc15', 0.95)
  ctx.lineWidth = 2
  const lx = U.x + 22
  rrPath(ctx, lx - 5, pcy - 2, 10, 9, 2)
  ctx.stroke()
  ctx.beginPath()
  ctx.arc(lx, pcy - 6, 4, Math.PI, TAU)
  ctx.stroke()
  ctx.fillStyle = 'rgba(225,235,255,0.92)'
  ctx.font = `600 15px ${FONT}`
  ctx.textAlign = 'left'
  ctx.textBaseline = 'middle'
  ctx.fillText(URL_TEXT, lx + 14, pcy)
  // viewport: loading — deliberately EMPTY of any page content
  rrPath(ctx, V.x, V.y, V.w, V.h, 14)
  ctx.fillStyle = 'rgba(10,14,32,0.96)'
  ctx.fill()
  ctx.save()
  rrPath(ctx, V.x, V.y, V.w, V.h, 14)
  ctx.clip()
  const prog = clamp(0.16 + s.beatIndex * 0.045 + 0.05 * Math.sin(s.t * 0.0009), 0.1, 0.9)
  rrPath(ctx, V.x + 24, V.y + 22, (V.w - 48) * prog, 6, 3)
  ctx.fillStyle = hexA('#22d3ee', 0.8)
  ctx.fill()
  const a = s.t * 0.006
  ctx.strokeStyle = hexA('#22d3ee', 0.9)
  ctx.lineWidth = 3
  ctx.beginPath()
  ctx.arc(V.x + V.w / 2, V.y + V.h / 2 - 10, 16, a, a + Math.PI * 1.4)
  ctx.stroke()
  ctx.fillStyle = 'rgba(170,180,224,0.55)'
  ctx.font = `500 18px ${FONT}`
  ctx.textAlign = 'center'
  ctx.textBaseline = 'alphabetic'
  ctx.fillText(`Waiting for ${URL_TEXT.replace('https://', '')}\u2026`, V.x + V.w / 2, V.y + V.h / 2 + 34)
  ctx.restore()
  // name under the frame
  ctx.textAlign = 'center'
  ctx.textBaseline = 'top'
  ctx.fillStyle = active ? '#ffffff' : hexA('#aab4d0', 0.55)
  ctx.font = `700 16px ${FONT}`
  if (active) {
    ctx.shadowColor = e.color
    ctx.shadowBlur = 10
  }
  ctx.fillText(e.name, W.x + W.w / 2, W.y + W.h + 18)
  ctx.restore()
}

// ===========================================================================
// PORT — the NIC seen from inside (ceiling door of the receiving machine).
// ===========================================================================
export const drawPort: EntityRenderer = (ctx, s, e, active) => {
  ctx.save()
  ctx.globalAlpha = active ? 1 : 0.6
  if (active) glow(ctx, e.pos, e.color, 90, 0.4 + 0.1 * Math.sin(s.t * 0.006))
  const w = 78
  const h = 46
  rrPath(ctx, e.pos.x - w / 2, e.pos.y - h / 2, w, h, 10)
  ctx.fillStyle = hexA(e.color, active ? 0.2 : 0.1)
  ctx.fill()
  ctx.strokeStyle = hexA(e.color, active ? 0.95 : 0.5)
  ctx.lineWidth = 2
  ctx.stroke()
  // down-arrow: pieces enter here
  ctx.strokeStyle = hexA(active ? '#ffffff' : e.color, 0.9)
  ctx.lineWidth = 3
  ctx.lineCap = 'round'
  ctx.beginPath()
  ctx.moveTo(e.pos.x, e.pos.y - 12)
  ctx.lineTo(e.pos.x, e.pos.y + 8)
  ctx.moveTo(e.pos.x - 8, e.pos.y)
  ctx.lineTo(e.pos.x, e.pos.y + 8)
  ctx.lineTo(e.pos.x + 8, e.pos.y)
  ctx.stroke()
  ctx.restore()
  drawName(ctx, e.pos, e.name, e.color, active, 34, 13)
}

// ===========================================================================
// WIRE TRAFFIC — the beat-driven payload painter of scene A: the imagined
// road, the mesh cables (revealed in b1), the file block, the packet chips,
// other people's dim traffic, the NIC tray. Pure f(beatIndex, beatElapsed, t).
// ===========================================================================
export const drawWireTraffic: EntityRenderer = (ctx, s) => {
  const bi = s.beatIndex
  const { lin } = beatFrac(s)
  ctx.save()

  // ---- the imagined straight road (the learner's Ch-02 picture) ----
  if (bi <= 1) {
    const ga = bi === 0 ? 0.32 : 0.32 * (1 - lin)
    if (ga > 0.01) {
      ctx.save()
      ctx.strokeStyle = hexA('#aab4d0', ga)
      ctx.lineWidth = 2
      ctx.setLineDash([4, 12])
      ctx.beginPath()
      ctx.moveTo(EDGE.x, EDGE.y)
      ctx.lineTo(DOOR.x, DOOR.y)
      ctx.stroke()
      ctx.restore()
    }
  }

  // ---- the mesh cables (revealed during b1, persistent after) ----
  if (bi >= 1) {
    const rf = bi === 1 ? easeInOutCubic(lin) : 1
    ctx.save()
    ctx.lineCap = 'round'
    for (const c of CABLES) {
      const f = easeInOutCubic(clamp((rf - c.reveal[0]) / (c.reveal[1] - c.reveal[0]), 0, 1))
      if (f <= 0.01) continue
      const end = lerpPt(c.a, c.b, f)
      ctx.strokeStyle = hexA('#a78bfa', 0.26)
      ctx.lineWidth = 3.5
      ctx.beginPath()
      ctx.moveTo(c.a.x, c.a.y)
      ctx.lineTo(end.x, end.y)
      ctx.stroke()
    }
    ctx.restore()
  }

  // ---- b0/b1: the file block hovers above the server's door ----
  if (bi <= 1) {
    drawFileBlock(ctx, { x: HOVER.x, y: HOVER.y + Math.sin(s.t * 0.004) * 4 }, 1)
  }

  // ---- b2: the whole-file attempt (the imagined failure) ----
  if (bi === 2) {
    drawFileBlock(ctx, s.sparkPos, 1)
    // other people's traffic queues behind the giant block
    for (let k = 0; k < 2; k++) {
      const bx = s.sparkPos.x - 66 - k * 24
      const by = HOVER.y + (k === 0 ? -13 : 12) + Math.sin(s.t * 0.005 + k * 2) * 3
      ctx.fillStyle = hexA(k === 0 ? '#22d3ee' : '#a5b4fc', 0.3)
      ctx.beginPath()
      ctx.arc(bx, by, 4.5, 0, TAU)
      ctx.fill()
    }
    // one bad bit spoils the stream
    if (lin > 0.52) {
      const fl = Math.sin((lin - 0.52) * 40)
      ctx.fillStyle = hexA('#fb7185', 0.55 + 0.4 * fl)
      ctx.fillRect(s.sparkPos.x + 12, s.sparkPos.y - 6, 12, 12)
      if (lin > 0.7) {
        ctx.fillStyle = hexA('#fb7185', 0.9)
        ctx.font = `800 20px ${FONT}`
        ctx.textAlign = 'center'
        ctx.textBaseline = 'bottom'
        ctx.fillText('!', s.sparkPos.x, s.sparkPos.y - 26)
      }
    }
  }

  // ---- b3: the slice (block holds above the door, cut lines flash, chips pop) ----
  if (bi === 3) {
    const retreat = easeInOutCubic(clamp(lin / 0.25, 0, 1))
    const bx = lerp(CLOG.x, HOVER.x, retreat)
    const by = HOVER.y
    const blockA = 1 - easeInOutCubic(clamp((lin - 0.55) / 0.2, 0, 1))
    if (blockA > 0.01) drawFileBlock(ctx, { x: bx, y: by }, blockA)
    // cut lines
    for (let c = 0; c < 3; c++) {
      const cutAt = 0.3 + 0.1 * c
      if (lin > cutAt && lin < cutAt + 0.09 && blockA > 0.3) {
        const fa = Math.sin((Math.PI * (lin - cutAt)) / 0.09)
        ctx.strokeStyle = hexA('#ffffff', 0.85 * fa)
        ctx.lineWidth = 2
        ctx.beginPath()
        ctx.moveTo(bx - 30 + c * 30, by - 24)
        ctx.lineTo(bx - 30 + c * 30, by + 24)
        ctx.stroke()
      }
    }
    // chips pop to the formation fan
    for (let k = 0; k < 5; k++) {
      const at = 0.55 + 0.045 * k
      if (lin <= at) continue
      const f = easeInOutCubic(clamp((lin - at) / 0.18, 0, 1))
      const pos = lerpPt({ x: bx, y: by }, CHIP_FORMATION[k], f)
      drawChip(ctx, pos, k + 1, f, 0.6 + 0.4 * f)
    }
  }

  // ---- b4: the road in motion (chip 1 rides the spark; siblings stream;
  // packet 2 takes the branch; packet 4 fizzles at the congested R2) ----
  if (bi === 4) {
    // chip 1: join the spark, then ride it exactly (02 §13)
    const join = easeInOutCubic(clamp(lin / 0.06, 0, 1))
    drawChip(ctx, lerpPt(CHIP_FORMATION[0], s.sparkPos, join), 1, 0.95)
    // chips 2..5
    for (let idx = 1; idx < CHIP_WINDOWS.length; idx++) {
      const w = CHIP_WINDOWS[idx]
      const k = idx + 1
      const path = w.path === 'main' ? MAIN_PATH : BRANCH_PATH
      if (lin < w.from) {
        // waits in the formation, bobbing
        drawChip(ctx, { x: CHIP_FORMATION[idx].x, y: CHIP_FORMATION[idx].y + Math.sin(s.t * 0.005 + k) * 3 }, k, 0.5, 0.9)
        continue
      }
      const param = easeInOutCubic(clamp((lin - w.from) / (w.to - w.from), 0, 1)) * (w.drop ? DROP_PARAM : 1)
      const blended = easeInOutCubic(clamp((lin - w.from) / 0.05, 0, 1))
      let pos = lerpPt(CHIP_FORMATION[idx], polylinePoint(path, param), blended)
      if (lin >= w.from + 0.05) pos = polylinePoint(path, param)
      if (w.drop && lin > w.to) {
        // fizzle at the congested Router: red flash, shrink, a small x
        const fz = clamp((lin - w.to) / 0.08, 0, 1)
        const dropPos = polylinePoint(path, DROP_PARAM)
        if (fz < 1) {
          ctx.strokeStyle = hexA('#fb7185', 0.9 * (1 - fz))
          ctx.lineWidth = 2.5
          ctx.beginPath()
          ctx.arc(dropPos.x, dropPos.y, 16 + 14 * fz, 0, TAU)
          ctx.stroke()
          drawChip(ctx, dropPos, k, 1 - fz, 1 - 0.6 * fz)
        }
        const xA = clamp(1 - (lin - w.to - 0.08) / 0.25, 0, 1)
        if (xA > 0.01) {
          ctx.fillStyle = hexA('#fb7185', 0.75 * xA)
          ctx.font = `800 18px ${FONT}`
          ctx.textAlign = 'center'
          ctx.textBaseline = 'middle'
          ctx.fillText('\u00D7', dropPos.x, dropPos.y)
        }
        continue
      }
      if (lin > w.to) {
        // arrived: cluster quietly at the NIC
        const off = { x: (idx - 2.5) * 16, y: -8 }
        drawChip(ctx, { x: NIC_POS.x + off.x, y: NIC_POS.y + off.y }, k, 0.5, 0.8)
        continue
      }
      drawChip(ctx, pos, k, 0.34)
    }
  }

  // ---- b5: the disordered tray (arrival order 1, 3, 5, 2; ghost for 4) ----
  if (bi === 5) {
    const hover = (k: number): Vec2 => ({
      x: NIC_POS.x + (k * 17 - 34),
      y: 772 - (k % 2) * 8 + Math.sin(s.t * 0.005 + k) * 3,
    })
    for (const land of TRAY_LANDING) {
      const from = land.from === 0.05 ? s.sparkPos : hover(land.chip)
      let pos: Vec2
      let alpha = 0.9
      if (lin < land.from) {
        pos = land.chip === 1 ? s.sparkPos : hover(land.chip)
        alpha = 0.55
      } else if (lin < land.to) {
        pos = lerpPt(from, TRAY_POS[TRAY_LANDING.indexOf(land)], easeInOutCubic((lin - land.from) / (land.to - land.from)))
      } else {
        pos = TRAY_POS[TRAY_LANDING.indexOf(land)]
      }
      drawChip(ctx, pos, land.chip, alpha, 0.92)
    }
    // the ghost slot: number 4 never showed up
    if (lin > 0.72) {
      const pu = 0.35 + 0.25 * Math.sin(s.t * 0.007)
      ctx.save()
      ctx.strokeStyle = hexA('#fb7185', pu)
      ctx.lineWidth = 2
      ctx.setLineDash([5, 6])
      rrPath(ctx, TRAY_GHOST.x - 27, TRAY_GHOST.y - 17, 54, 34, 8)
      ctx.stroke()
      ctx.setLineDash([])
      ctx.fillStyle = hexA('#fb7185', pu + 0.2)
      ctx.font = `800 18px ${FONT}`
      ctx.textAlign = 'center'
      ctx.textBaseline = 'middle'
      ctx.fillText('?', TRAY_GHOST.x, TRAY_GHOST.y)
      ctx.restore()
    }
  }

  // ---- b12: the road stays alive (ambient dim traffic while the spark loops) ----
  if (bi >= 12) {
    for (let k = 0; k < 5; k++) {
      const c = CABLES[(k * 2) % CABLES.length]
      const f = (s.t * 0.00005 * (k + 1) + k * 0.37) % 1
      const p = lerpPt(c.a, c.b, f)
      ctx.fillStyle = hexA(k % 2 === 0 ? '#22d3ee' : '#a5b4fc', 0.16)
      ctx.beginPath()
      ctx.arc(p.x, p.y, 3.2, 0, TAU)
      ctx.fill()
    }
  }

  ctx.restore()
}

// ===========================================================================
// REASSEMBLY BENCH — TCP's workshop: numbered slots, the ACK counter, the
// ask, the merge. Same beat-driven pattern as Ch-02's workbench, normalized
// by the beat's REAL duration.
// ===========================================================================
export const drawReassemblyBench: EntityRenderer = (ctx, s, e, active) => {
  const r = BENCH
  const bi = s.beatIndex
  const { lin } = beatFrac(s)
  const stage = STAGE_AT_BEAT[bi] ?? ''

  ctx.save()
  if (active) glow(ctx, e.pos, e.color, 140, 0.16)
  rrPath(ctx, r.x, r.y, r.w, r.h, 20)
  ctx.fillStyle = 'rgba(13,19,42,0.94)'
  ctx.fill()
  ctx.strokeStyle = hexA('#e2e8f0', active ? 0.5 : 0.22)
  ctx.lineWidth = 2
  ctx.stroke()
  const cap = STAGE_CAPTIONS[stage]
  if (cap) {
    ctx.fillStyle = hexA('#aab4d0', 0.7)
    ctx.font = `700 15px ${FONT}`
    ctx.textAlign = 'left'
    ctx.textBaseline = 'top'
    ctx.fillText(cap, r.x + 18, r.y + 12)
  }

  // ---- which slots hold a chip at rest at the start of this beat ----
  const settled = new Set<number>(SLOTS_AT_BEAT[bi] ?? [])
  const incoming = INCOMING[stage] ?? []
  const incomingN = new Set(incoming.map((x) => x.n))
  // merge: strips leave each slot at a staggered time
  const leaveAt = (k: number) => 0.06 + k * 0.05

  // ---- slots ----
  for (let k = 0; k < 5; k++) {
    const n = k + 1
    const p = SLOT_POS[k]
    const inMerge = stage === 'merge'
    // a slot only asserts "occupied" once its incoming piece is nearly in
    // (structure vs state, 02 §4) — or while a settled chip rests there
    const inc = incoming.find((x) => x.n === n)
    const inf = inc ? easeInOutCubic(clamp((lin - inc.a) / (inc.b - inc.a), 0, 1)) : 0
    const present = inMerge ? lin < leaveAt(k) : settled.has(n) || inf > 0.6
    const gapPulse = n === 4 && ((bi === 8 && lin > 0.62) || (bi === 9 && lin < 0.45))
    ctx.save()
    rrPath(ctx, p.x - SLOT_W / 2, p.y - SLOT_W / 2, SLOT_W, SLOT_W, 12)
    ctx.fillStyle = hexA('#facc15', present ? 0.07 : 0.03)
    ctx.fill()
    if (gapPulse) {
      ctx.strokeStyle = hexA('#fb7185', 0.4 + 0.3 * Math.sin(s.t * 0.008))
      ctx.lineWidth = 2.5
      ctx.setLineDash([6, 7])
    } else {
      ctx.strokeStyle = hexA('#e2e8f0', 0.3)
      ctx.lineWidth = 1.8
      ctx.setLineDash(present ? [] : [6, 7])
    }
    ctx.stroke()
    ctx.setLineDash([])
    ctx.fillStyle = hexA('#aab4d0', 0.75)
    ctx.font = `800 15px ${MONO}`
    ctx.textAlign = 'center'
    ctx.textBaseline = 'top'
    ctx.fillText(String(n), p.x, p.y + SLOT_W / 2 + 8)
    ctx.restore()
    // settled chip (drawn while parked; the incoming-draw handles a piece in transit)
    if (settled.has(n) && !incomingN.has(n) && !(inMerge && lin >= leaveAt(k))) {
      drawChip(ctx, p, n, 0.95)
    }
  }

  // ---- pieces descending from the port, full alpha the whole beat (the clamped
  //      descent parks them in their slot after landing) ----
  for (const inc of incoming) {
    if (lin < inc.a) continue
    const f = easeInOutCubic(clamp((lin - inc.a) / (inc.b - inc.a), 0, 1))
    drawChip(ctx, lerpPt(PORT, SLOT_POS[inc.n - 1], f), inc.n, 0.95)
    ackDrift(ctx, SLOT_POS[inc.n - 1], s.t, clamp((lin - inc.b) / 0.16, 0, 1))
  }

  // ---- the ask rises out through the port (b9) ----
  if (stage === 'ask' && lin < 0.35) {
    const f = easeInOutCubic(clamp(lin / 0.3, 0, 1))
    const pos = lerpPt({ x: r.x + r.w - 100, y: r.y + 66 }, PORT, f)
    ctx.save()
    ctx.globalAlpha = 1 - clamp((lin - 0.24) / 0.11, 0, 1)
    rrPath(ctx, pos.x - 42, pos.y - 15, 84, 30, 15)
    ctx.fillStyle = hexA('#fb7185', 0.25)
    ctx.fill()
    ctx.strokeStyle = hexA('#fb7185', 0.95)
    ctx.lineWidth = 2
    ctx.stroke()
    ctx.fillStyle = '#fda4af'
    ctx.font = `800 13px ${MONO}`
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    ctx.fillText('need #4', pos.x, pos.y)
    ctx.restore()
  }

  // ---- merge: strips leave slots -> gather into a column -> converge -> fuse ----
  if (stage === 'merge') {
    const colPos = (k: number): Vec2 => ({ x: 560 + k * 70, y: MERGE.y })
    for (let k = 0; k < 5; k++) {
      const n = k + 1
      const lv = leaveAt(k)
      if (lin >= 0.62) continue // fused into the block
      let pos: Vec2
      if (lin < lv) pos = SLOT_POS[k]
      else if (lin < 0.45) {
        pos = lerpPt(SLOT_POS[k], colPos(k), easeInOutCubic(clamp((lin - lv) / (0.45 - lv), 0, 1)))
      } else {
        pos = lerpPt(colPos(k), MERGE, easeInOutCubic(clamp((lin - 0.45) / 0.17, 0, 1)))
      }
      const fade = lin < 0.45 ? 1 : 1 - clamp((lin - 0.5) / 0.12, 0, 1)
      drawStrip(ctx, pos, n, fade)
    }
    const blockA = clamp((lin - 0.62) / 0.18, 0, 1)
    if (blockA > 0.01) {
      const glide = lin > 0.8 ? easeInOutCubic(clamp((lin - 0.8) / 0.2, 0, 1)) : 0
      const pos = lerpPt(MERGE, RAM_DOOR, glide)
      drawFileBlock(ctx, pos, blockA, lerp(0.7, 1, blockA))
      if (lin > 0.78 && lin < 0.92 && glide < 0.2) {
        const pop = easeInOutCubic(clamp((lin - 0.78) / 0.1, 0, 1))
        ctx.save()
        ctx.globalAlpha = pop
        rrPath(ctx, pos.x + 44, pos.y - 34, 86, 26, 13)
        ctx.fillStyle = hexA('#4ade80', 0.2)
        ctx.fill()
        ctx.strokeStyle = hexA('#4ade80', 0.9)
        ctx.lineWidth = 1.8
        ctx.stroke()
        ctx.fillStyle = '#86efac'
        ctx.font = `800 13px ${MONO}`
        ctx.textAlign = 'center'
        ctx.textBaseline = 'middle'
        ctx.fillText('whole \u2713', pos.x + 87, pos.y - 21)
        ctx.restore()
      }
    }
  }

  // ---- ACK counter: advances only in order ----
  let ack = ACK_START[bi] ?? 5
  const ff = ACK_FLIP[bi] ?? 2
  if (lin >= ff) ack = ACK_AT_BEAT[bi] ?? ack
  const cx0 = r.x + r.w - 176
  const cy0 = r.y + 14
  const justFlipped = lin >= ff && lin < ff + 0.15
  const pu = justFlipped ? 1 + 0.25 * (1 - (lin - ff) / 0.15) : 1
  ctx.save()
  rrPath(ctx, cx0, cy0, 156, 46, 10)
  ctx.fillStyle = hexA('#facc15', 0.08)
  ctx.fill()
  ctx.strokeStyle = hexA('#facc15', justFlipped ? 0.9 : 0.45)
  ctx.lineWidth = 1.8
  ctx.stroke()
  ctx.fillStyle = hexA('#aab4d0', 0.8)
  ctx.font = `800 11px ${MONO}`
  ctx.textAlign = 'left'
  ctx.textBaseline = 'middle'
  ctx.fillText('ACK', cx0 + 12, cy0 + 14)
  ctx.fillStyle = '#facc15'
  ctx.font = `800 ${Math.round(22 * pu)}px ${MONO}`
  ctx.textAlign = 'right'
  ctx.fillText(`have \u2713${ack}`, cx0 + 144, cy0 + 27)
  ctx.restore()

  ctx.restore()
  drawName(ctx, { x: r.x + r.w / 2, y: r.y + r.h }, e.name, e.color, active, 10, 16)
}

// a small dim checkmark drifting up to the port (the ACK foreshadow)
function ackDrift(ctx: CanvasRenderingContext2D, from: Vec2, t: number, f: number) {
  if (f <= 0.01 || f >= 1) return
  const pos = lerpPt({ x: from.x, y: from.y - 30 }, PORT, f)
  ctx.save()
  ctx.globalAlpha = 0.5 * (1 - f)
  ctx.fillStyle = '#4ade80'
  ctx.font = `800 16px ${MONO}`
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText('\u2713', pos.x, pos.y)
  ctx.restore()
}

// a payload strip (a chip without its header band — the raw slice)
function drawStrip(ctx: CanvasRenderingContext2D, pos: Vec2, n: number, alpha: number) {
  if (alpha <= 0.01) return
  ctx.save()
  ctx.globalAlpha = alpha
  rrPath(ctx, pos.x - 24, pos.y - 11, 48, 22, 6)
  ctx.fillStyle = hexA('#facc15', 0.22)
  ctx.fill()
  ctx.strokeStyle = hexA('#facc15', 0.85)
  ctx.lineWidth = 1.6
  ctx.stroke()
  ctx.fillStyle = '#fff'
  ctx.font = `800 12px ${MONO}`
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(String(n), pos.x, pos.y)
  ctx.restore()
}
